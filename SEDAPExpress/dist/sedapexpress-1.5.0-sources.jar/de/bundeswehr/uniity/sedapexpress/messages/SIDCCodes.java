/**
 * Note: This license has also been called the “Simplified BSD License” and the “FreeBSD License”.
 *
 * Copyright 2024-2026 UNIITY POC: Volker Voß, Federal Armed Forces of Germany
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSEnARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 */
package de.bundeswehr.uniity.sedapexpress.messages;

import java.util.Arrays;
import java.util.List;

/**
 * 
 * @author Volker Voß
 *
 */
public class SIDCCodes {

	public static final String[] spaceCodesArray = new String[] { "------|0", "------|0", "------|Unknown", "s-----|Satellite", "v-----|Crewed space vehicle", "t-----|Space station",
			"l-----|Space launch vehicle" };
	public static final List<String> spaceCodesList = Arrays.asList(SIDCCodes.spaceCodesArray);

	public static final String[] airCodesArray = new String[] { "------|0", "------|No statement", "m-----|MILITARY", "mf----|FIXED WING", "mfb---|BOMBER", "mff---|FIGHTER", "mffi--|INTERCEPTOR",
			"mft---|TRAINER", "mfa---|ATTACK", "mfl---|V/STOL", "mfk---|TANKER", "mfkb--|BOOM-ONLY", "mfkd--|DROGUE-ONLY", "mfc---|CARGO", "mfcl--|LIGHT", "mfcm--|MEDIUM", "mfch--|HEAVY",
			"mfj---|ECM", "mfo---|MEDEVAC", "mfr---|RECON", "mfrw--|AEW", "mfrz--|ESM", "mfrx--|PHOTO", "mfp---|PATROL", "mfpn--|ASUW", "mfpm--|MCM", "mfu---|UTILITY", "mful--|LIGHT", "mfum--|MEDIUM",
			"mfuh--|HEAVY", "mfy---|COMM", "mfh---|CSAR", "mfd---|AIRBONE C2", "mfq---|DRONE", "mfqa--|ATTACK", "mfqb--|BOMBER", "mfqc--|CARGO", "mfqd--|AIRBORNE C2", "mfqf--|FIGHTER", "mfqh--|CSAR",
			"mfqj--|ECM/JAMMER", "mfqk--|TANKER", "mfql--|V/STOL", "mfqm--|SOF", "mfqi--|MCM", "mfqn--|ASUW", "mfqp--|PATROL", "mfqr--|RECONN", "mfqrw-|AEW", "mfqrz-|ESM", "mfqrx-|PHOTO",
			"mfqs--|SAW", "mfqt--|TRAINER", "mfqu--|UTILITY", "mfqy--|COMM", "mfqo--|MEDEVAC", "mfs---|ASW", "mfm---|SOF", "mh----|ROTARY WING", "mha---|ATTACK", "mhs---|ASUW/MPA", "mhu---|UTILITY",
			"mhul--|LIGHT", "mhum--|MEDIUM", "mhuh--|HEAVY", "mhi---|MCM", "mhh---|CSAR", "mhr---|RECONN", "mhq---|DRONE", "mhc---|CARGO", "mhcl--|LIGHT", "mhcm--|MEDIUM", "mhch--|HEAVY",
			"mht---|TRAINER", "mho---|MEDEVAC", "mhm---|SOF", "mhd---|AIRBORNE C2", "mhk---|TANKER", "mhj---|ECM/JAMMER", "ml----|LIGHTER-THAN-AIR", "mv----|VERY IMPORTANT PERSON", "me----|ESCORT",
			"w-----|WEAPON", "wm----|MISSLE-IN-FLIGHT", "wms---|SURFACE-LAUNCHED MISSLE", "wmss--|SURFACE-TO-SURFACE", "wmsa--|SURFACE-TO-AIR", "wmsu--|SURFACE-TO-SUBSURFACE",
			"wmsb--|ANTI-BALLISTIC-MISSILE", "wma---|AIR-LAUNCHED MISSLE", "wmas--|AIR-TO-SURFACE", "wmaa--|AIR-TO-AIR", "wmap--|AIR-TO-SPACE", "wmu---|SUBSURFACE-TO-SURFACE", "wmcm--|CRUISE MISSLE",
			"wmb---|BALLISTIC MISSLE", "wb----|BOMB", "wd----|DECOY", "c-----|CIVIL", "cf----|FIXED WING", "ch----|ROTARY WING", "cl----|LIGHTER-THAN-AIR" };
	public static final List<String> airCodesList = Arrays.asList(SIDCCodes.airCodesArray);

	public static final String[] surfaceCodesArray = new String[] { "------|0", "------|No statement", "c-----|Combatant", "cl----|Line", "clcv--|Carrier", "clbb--|Battleship", "clcc--|Cruiser",
			"cldd--|Destroyer", "clff--|Frigate/Corvette", "clll--|Littoral combatant", "clllas|ASW Mission package", "clllmi|MW Mission package", "clllsu|SUW Mission package",
			"ca----|Amphibious warfare ship", "cala--|Assault vessel", "cals--|Landing ship", "calsm-|Landing ship medium", "calst-|Landing ship tank", "calc--|Landing craft",
			"cm----|Mine warfare vessel", "cmml--|Minelayer", "cmms--|Minesweeper", "cmmh--|Minehunter", "cmma--|MCM Support", "cp----|Patrol", "cpsb--|ASW", "cpsu--|ASUW",
			"cpsum-|Missile patrol craft", "cpsut-|Torpedo patrol craft", "cpsug-|Gun patrol craft", "ch----|Hovercraft", "g-----|Navy group", "gt----|Navy task force", "gg----|Navy task group",
			"gu----|Navy task unit", "gc----|Convoy", "cd----|Surface decoy", "cu----|Unmanned surface vehicle", "cum---|MCM Surface drone", "cus---|ASW Surface drone", "cun---|ASUW Surface drone",
			"cur---|Remote multimission vehicle", "n-----|Non combatant", "nr----|Unterway replenishment", "nf----|Fleet support", "ni----|Intelligence", "ns----|Service&Support harbor",
			"nm----|Hospital ship", "nh----|Hovercraft", "x-----|Non military", "xm----|Merchant", "xmc---|Cargo", "xmr---|Roll on/Roll off", "xmo---|Oiler/Tanker", "xmtu--|Tug", "xmf---|Ferry",
			"xmp---|Passenger", "xmh---|Hazadous Materials", "xmto--|Towing vessel", "xf----|Fishing", "xfdf--|Drifter", "xfdr--|Dredge", "xftr--|Trawler", "xr----|Leisure craft",
			"xl----|Law enforcement vessel", "xh----|Hovercraft", "xa----|Fast recreactional craft", "xar---|Rigid-Hull inflatable boat", "xas---|Speed boat", "xp----|Personal watercraft" };
	public static final List<String> surfaceCodesList = Arrays.asList(SIDCCodes.surfaceCodesArray);

	public static final String[] subsurfaceCodesArray = new String[] { "------|0", "------|No statement", "s-----|Submarine", "sf----|Surfaced submarine", "sb----|Bottomed submarine",
			"sr----|Certain submarine", "sx----|Non-Submarine", "sn----|Nuclear propulsion", "snf---|Surfaced submarine", "sna---|Attack submarine", "snm---|Missile submarine",
			"sng---|Guided missile submarine", "snb---|Ballistic missle submarine", "sc----|Conventional propulsion", "scf---|Surfaced submarine", "sca---|Attack submarine",
			"scm---|Missile submarine", "scg---|Guided missile submarine", "scb---|Ballistic missle submarine", "so----|Other submersible", "sof---|Surfaced other submersible",
			"su----|Unmanned underwater vehicle", "sum---|MW subsurface drone", "sus---|ASW subsurface drone", "sun---|ASUW subsurface drone", "s1----|Possible submarine 1",
			"s2----|Possible submarine 2", "s3----|Possible submarine 3", "s4----|Possible submarine 4", "sl----|Probable submarine", "sk----|Snorkeling submarine", "w-----|Underwater weapon",
			"wt----|Torpedo", "wm----|Sea mine", "wmd---|Sea mine (neutralized)", "wmg---|Sea mine (ground)", "wmgd--|Sea mine (ground, neutralized)", "wmgx--|Ground exercice mine",
			"wmge--|Ground mine-like echo (MILEC)", "wmgc--|Ground mine-like contact (MILCO)", "wmgr--|Ground negative reacquisition", "wmgo--|Ground non-mine mine-like contact",
			"wmm---|Sea mine (moored)", "wmmd--|Sea mine (moored) neutralized", "wmmx--|Moored exercise mine", "wmme--|Moored mine-like echo", "wmmc--|Moored mine-like contact",
			"wmmr--|Moored negative reacquisition", "wmmo--|Moored non-mine mine-like object", "wmf---|Sea mine (floating)", "wmfd--|Sea mine (floating) neutralized", "wmfx--|Floating exercise mine",
			"wmfe--|Floating mine-like echo (MILEC)", "wmfc--|Floating mine-like contact (MILCO)", "wmfr--|Floating negative reacquisition", "wmfo--|Floating non-mine mine-like contact",
			"wmo---|Sea mine (other position)", "wmod--|Sea mine (other position) neutralized", "wmx---|General exercise mine", "wme---|General mine-like echo (MILEC)", "wma---|General mine anchor",
			"wmc---|General mine-like contact (MILCO)", "wmr---|General negative reacquisition", "wmb---|General Obstructor", "wmbd--|General non-mine mine-like object", "wms---|Rising mine",
			"wmsx--|Rising exercise mine", "wmsd--|Rising neutralized mine", "wd----|Underwater decoy", "wdm---|Sea mine decoy", "wdmg--|Ground decoy", "wdmm--|Moored decoy", "n-----|Non-submarine",
			"nd----|Diver", "e-----|Environmental report location", "v-----|Dive report location", "x-----|Unexploded ordnance area" };
	public static final List<String> subsurfaceCodesList = Arrays.asList(SIDCCodes.subsurfaceCodesArray);

	public static final String[] groundCodesArray = new String[] { "------|0", "------|No statement", "u-----|Unit", "uc----|Combat", "ucd---|Air defense", "ucds--|Short range", "ucdsc-|Chaparral",
			"ucdss-|Stinger", "ucdsv-|Vulcan", "ucdm--|Air defense missile", "ucdml-|Air defense missile light", "ucdmla|Air defense missile motorized", "ucdmm-|Air defense missile medium",
			"ucdmh-|Air defense missile heavy", "ucdh--|H/MAD", "ucdhh-|Hawk", "ucdhp-|Patroit", "ucdg--|Gun unit", "ucdc--|Composite", "ucdt--|Targeting gun", "ucdo--|Theater missile defense unit",
			"uca---|Armor", "ucat--|Armor track", "ucata-|Armor track airborne", "ucatw-|Armor track ampibious", "ucatwr|Armor track amphibious recovery", "ucatl-|Armor track light",
			"ucatm-|Armor track medium", "ucath-|Armor track heavy", "ucatr-|Armor track recovery", "ucaw--|Armor wheeled", "ucaws-|Armor wheeled air assault", "ucawa-|Armor wheeled airborne",
			"ucaww-|Armor wheeled amphibious", "ucawwr|Armor wheeled amphibious recovery", "ucawk-|Armor wheeled light", "ucawm-|Armor wheeled medium", "ucawh-|Armor wheeled heavy",
			"ucawr-|Armor wheeled recovery", "ucaa--|Anti-Armor", "ucaad-|Anti-Armor dismounted", "ucaal-|Anti-Armor light", "ucaam-|Anti-Armor airborne", "ucaas-|Anti-Armor air assault",
			"ucaau-|Anti-Armor mountain", "ucaac-|Anti-Armor arctic", "ucaaa-|Anti-Armor armored", "ucaaat|Anti-Armor armored tracked", "ucaaaw|Anti-Armor armored wheeled",
			"ucaaas|Anti-Armor armored air assault", "ucaao-|Anti-Armor motorized", "ucaaos|Anti-Armor motorized air assault", "ucv---|Aviation", "ucvf--|Fixed wing", "ucvfu-|Utility fixed wing",
			"ucvfa-|Attack fixed wing", "ucvfr-|Recon fixed wing", "ucvr--|Rotary wing", "ucvra-|Attack rotary wing", "ucvrs-|Scout rotary wing", "ucvrw-|ASW rotary wing",
			"ucvru-|Utility rotary wing", "ucvrul|Light utility rotary wing", "ucvrum|Medium utility rotary wing", "ucvruh|Heavy utility rotary wing", "ucvruc|C2 rotary wing",
			"ucvrue|Medevac rotary wing", "ucvrm-|MCM rotary wing", "ucvs--|Search and rescue", "ucvc--|Composite", "ucvv--|V/STOL", "ucvu--|Unmanned aircraft", "ucvuf-|Unmanned aircraft fixed wing",
			"ucvur-|Unmanned aircraft rotary wing", "uci---|Infantry", "ucil--|Infantry light", "ucim--|Infantry motorized", "ucio--|Infantry mountain", "ucia--|Infantry airborne",
			"ucis--|Infantry air assault", "uciz--|Infantry mechanized", "ucin--|Infantry naval", "ucii--|Infantry fighting vehicle", "ucic--|Infantry arctic", "uce---|Engineer",
			"ucec--|Engineer combat", "ucecs-|Engineer combat air assault", "uceca-|Engineer combat airborne", "ucecc-|Engineer combat arctic", "ucecl-|Engineer combat light",
			"ucecm-|Engineer combat medium", "ucech-|Engineer combat heavy", "ucect-|Engineer combat mechanized", "ucecw-|Engineer combat motorized", "uceco-|Engineer combat mountain",
			"ucecr-|Engineer combat recon", "ucen--|Engineer construction", "ucenn-|Engineer naval construction", "ucf---|Field artillery", "ucfh--|Howitzer/Gun", "ucfhe-|Self-Propelled",
			"ucfhs-|Air assault", "ucfha-|Airborne", "ucfhc-|Arctic", "ucfho-|Mountain", "ucfhl-|Light", "ucfhm-|Medium", "ucfhh-|Heavy", "ucfhx-|Amphibious", "ucfr--|Rocket",
			"ucfrs-|Single rocket launcher", "ucfrss|Single rocket launcher self-propelled", "ucfrsr|Single rocket launcher truck", "ucfrst|Single rocket launcher towed",
			"ucfrm-|Mutiple rocket launcher", "ucfrms|Mutiple rocket launcher self-propelled", "ucfrmr|Mutiple rocket launcher truck", "ucfrmt|Mutiple rocket launcher towed",
			"ucft--|Target acquisition", "ucftr-|Radar", "ucfts-|Sound", "ucftf-|Flash", "ucftc-|Colt/Fist", "ucftcd|Dismounted colt/fist", "ucftcm|Tracked colt/fist", "ucfta-|Anglico",
			"ucfm--|Mortar", "ucfms-|Self-Propelled tracked mortar", "ucfmw-|Self-Propelled wheeled mortar", "ucfmt-|Towed mortar", "ucfmta|Towed airborne mortar", "ucfmts|Towed air assault mortar",
			"ucfmtc|Towed arctic mortar", "ucfmto|Towed mountain mortar", "ucfml-|Amphibious mortar", "ucfs--|Artillery survey", "ucfss-|Air assault", "ucfsa-|Airborne", "ucfsl-|Light",
			"ucfso-|Mountain", "ucfo--|Meteorological", "ucfos-|Air assault meteorological", "ucfoa-|Airborne meteorological", "ucfol-|Light meteorological", "ucfoo-|Mountain meteorological",
			"ucr---|Reconnaissance", "ucrh--|Reconnaissance horse", "ucrv--|Reconnaissance cavalry", "ucrvs-|Reconnaissance cavalry armored", "ucrvm-|Reconnaissance cavalry motorized",
			"ucrvg-|Reconnaissance cavalry ground", "ucrvo-|Reconnaissance cavalry air", "ucrc--|Reconnaissance arctic", "ucrs--|Reconnaissance air assault", "ucra--|Reconnaissance airborne",
			"ucro--|Reconnaissance mountain", "ucrl--|Reconnaissance light", "ucrr--|Reconnaissance marine", "ucrrd-|Reconnaissance marine division", "ucrrf-|Reconnaissance marine force",
			"ucrrl-|Reconnaissance marine light armored", "ucrx--|Reconnaissance long range surveillance", "ucm---|Missile (Surf-Surf)", "ucmt--|Missile (Surf-Surf) tactical",
			"ucms--|Missile (Surf-Surf) strategic", "ucs---|Internal security forces", "ucsw--|Riverine", "ucsg--|Ground", "ucsgd-|Dismounted ground", "ucsgm-|Motorized ground",
			"ucsga-|Mechanized ground", "ucsm--|Wheeled mechanized", "ucsr--|Railroad", "ucsa--|Aviation", "uu----|Combat support", "uua---|Combat support cbrn", "uuac--|Chemical",
			"uuacc-|Smoke/Decon", "uuacck|Mechanized smoke/decon", "uuaccm|Motorized smoke/decon", "uuacs-|Smoke", "uuacsm|Motorized smoke", "uuacsa|Armor smoke", "uuacr-|Chemical recon",
			"uuacrw|Chemical wheeled armored vehicle", "uuacrs|Chemical wheeled armored vehicle recon", "uuan--|Nuclear", "uuab--|Biological", "uuabr-|Recon equipped", "uuad--|Decontamination",
			"uum---|Military intelligence", "uuma--|Areal exploitation", "uums--|Signal intelligence", "uumse-|Electronic warfare", "uumsea|Armored wheeled vehicle", "uumsed|Direction finding",
			"uumsei|Intercept", "uumsej|Jamming", "uumset|Theater", "uumsec|Corps", "uumc--|Counterintelligence", "uumr--|Surveillance", "uumrg-|Ground surveillance radar", "uumrs-|Sensor",
			"uumrss|Sensor scm", "uumrx-|Ground station module", "uummo-|Meteorological", "uumo--|Operations", "uumt--|Tactical exploit", "uumq--|Interrogation", "uumj--|Joint intelligence center",
			"uul---|Law enforcement unit", "uuls--|Shore patrol", "uulm--|Military police", "uulc--|Civilian law enforcement", "uulf--|Security police", "uuld--|Central intelligence division",
			"uus---|Signal unit", "uusa--|Area", "uusc--|Communication configured package", "uuscl-|Large communication configured package", "uuso--|Command operations",
			"uusf--|Forward communications", "uusm--|Multiple subscriber element", "uusms-|Small extension node", "uusml-|Large extension node", "uusmn-|Node center", "uusr--|Radio unit",
			"uusrs-|Tactical satellite", "uusrt-|Teletype center", "uusrw-|Relay", "uuss--|Signal support", "uusw--|Telephone switch", "uusx--|Electronic raging", "uui---|Information warfare unit",
			"uup---|Landing support", "uue---|Explosive ordnance disposal", "us----|Combat service support", "usa---|Administrative/Admin", "usat--|Admin theater", "usac--|Admin corps",
			"usaj--|Judge advocate general (JAG)", "usajt-|JAG Theater", "usajc-|JAG Corps", "usao--|Postal", "usaot-|Postal theater", "usaoc-|Postal corps", "usaf--|Finance",
			"usaft-|Finance theater", "usafc-|Finance corps", "usas--|Personnel services", "usast-|Personnel theater", "usasc-|Personnel corps", "usam--|Mortuary/Graves registry",
			"usamt-|Mortuary/Graves registry theater", "usamc-|Mortuary/Graves registry corps", "usar--|Religious/Chaplain", "usart-|Religious/Chaplain theater", "usarc-|Religious/Chaplain corps",
			"usap--|Public affairs", "usapt-|Public affairs theater", "usapc-|Public affairs corps", "usapb-|Public affairs broadcast", "usapbt|Public affairs broadcast theater",
			"usapbc|Public affairs broadcast corps", "usapm-|Public affairs joint information bureau (JIB)", "usapmt|Public affairs JIB theater", "usapmc|Public affairs JIB corps",
			"usax--|Replacement holding unit", "usaxt-|Replacement holding unit theater", "usaxc-|Replacement holding unit corps", "usal--|Labor", "usalt-|Labor theater", "usalc-|Labor corps",
			"usaw--|Morale, Welfare, Recreation", "usawt-|Morale, Welfare, Recreation theater", "usawc-|Morale, Welfare, Recreation corps", "usaq--|Quartermaster (Supply)",
			"usaqt-|Quartermaster (Supply) theater", "usaqc-|Quartermaster (Supply) corps", "usm---|Medical", "usmt--|Medical theater", "usmc--|Medical corps", "usmm--|Medical treatment facility",
			"usmmt-|Medical treatment facility theater", "usmmc-|Medical treatment facility corps", "usmv--|Medical veterinary", "usmvt-|Medical veterinary theater", "usmvc-|Medical veterinary corps",
			"usmd--|Medical dental", "usmdt-|Medical dental theater", "usmdc-|Medical dental corps", "usmp--|Medical psychological", "usmpt-|Medical psychological theater",
			"usmpc-|Medical psychological corps", "uss---|Supply", "usst--|Supply theater", "ussc--|Supply corps", "uss1--|Supply class I", "uss1t-|Supply class I theater",
			"uss1c-|Supply class I corps", "uss2--|Supply class II", "uss2t-|Supply class II theater", "uss2c-|Supply class II corps", "uss3--|Supply class III", "uss3t-|Supply class III theater",
			"uss3c-|Supply class III corps", "uss4--|Supply class IV", "uss4t-|Supply class IV theater", "uss4c-|Supply class IV corps", "uss5--|Supply class V", "uss5t-|Supply class V theater",
			"uss5c-|Supply class V corps", "uss6--|Supply class VI", "uss6t-|Supply class VI theater", "uss6c-|Supply class VI corps", "uss7--|Supply class VII", "uss7t-|Supply class VII theater",
			"uss7c-|Supply class VII corps", "uss8--|Supply class VIII", "uss8t-|Supply class VIII theater", "uss8c-|Supply class VIII corps", "uss9--|Supply class IX",
			"uss9t-|Supply class IX theater", "uss9c-|Supply class IX corps", "ussx--|Supply class X", "ussxt-|Supply class X theater", "ussxc-|Supply class X corps", "ussl--|Supply Laundry/Bath",
			"usslt-|Supply Laundry/Bath theater", "usslc-|Supply Laundry/Bath corps", "ussw--|Supply water", "usswt-|Supply water theater", "usswc-|Supply water corps",
			"usswp-|Supply water purification", "usswpt|Supply water purification theater", "usswpc|Supply water purification corps", "ust---|Transportation", "ustt--|Transportation theater",
			"ustc--|Transportation corps", "ustm--|Movement control center (MCC)", "ustmt-|MCC theater", "ustmc-|MCC corps", "ustr--|Railhead", "ustrt-|Railhead theater", "ustrc-|Railhead corps",
			"usts--|SPOD/SPOE", "ustst-|SPOD/SPOE theater", "ustsc-|SPOD/SPOE corps", "usta--|APOD/APOE", "ustat-|APOD/APOE theater", "ustac-|APOD/APOE corps", "usti--|Missile",
			"ustit-|Missile theater", "ustic-|Missile corps", "usx---|Maintenance", "usxt--|Maintenance theater", "usxc--|Maintenance corps", "usxh--|Maintenance heavy",
			"usxht-|Maintenance heavy theater", "usxhc-|Maintenance heavy corps", "usxr--|Maintenance recovery", "usxrt-|Maintenance recovery theater", "usxrc-|Maintenance recovery corps",
			"usxo--|Ordnance", "usxot-|Ordnance theater", "usxoc-|Ordnance corps", "usxom-|Ordnance missile", "usxomt|Ordnance missile theater", "usxomc|Ordnance missile corps",
			"usxe--|Electro-optical", "usxet-|Electro-optical theater", "usxec-|Electro-optical corps", "uh----|Special C2 headquarters component", "e-----|Equipment", "ew----|Weapon",
			"ewm---|Missile launcher", "ewma--|Air defense missile launcher", "ewmas-|Short range air defense missile launcher", "ewmasr|Transporter launcher and radar (TLAR)",
			"ewmase|Transporter erector launcher and radar (TELAR)", "ewmai-|Intermediate range air defense missile launcher", "ewmair|Transporter launcher and radar (TLAR)",
			"ewmaie|Transporter erector launcher and radar (TELAR)", "ewmal-|Long range air defense missile launcher", "ewmalr|Transporter launcher and radar (TLAR)",
			"ewmale|Transporter erector launcher and radar (TELAR)", "ewmat-|Air defense missile launcher theater", "ewmatr|Transporter launcher and radar (TLAR)",
			"ewmate|Transporter erector launcher and radar (TELAR)", "ewms--|Surf-Surf missile launcher", "ewmss-|Short range missile launcher", "ewmsi-|Intermediate range missile launcher",
			"ewmsl-|Long range missile launcher", "ewmt--|Missile launcher anti-tank", "ewmtl-|Missile launcher anti-tank light", "ewmtm-|Missile launcher anti-tank medium",
			"ewmth-|Missile launcher anti-tank heavy", "ews---|Single rocket launcher", "ewsl--|Single rocket launcher light", "ewsm--|Single rocket launcher medium",
			"ewsh--|Single rocket launcher heavy", "ewx---|Multiple rocket launcher", "ewxl--|Multiple rocket launcher light", "ewxm--|Multiple rocket launcher medium",
			"ewxh--|Multiple rocket launcher heavy", "ewt---|Anti-tank rocket launcher", "ewtl--|Anti-tank rocket launcher light", "ewtm--|Anti-tank rocket launcher medium",
			"ewth--|Anti-tank rocket launcher heavy", "ewr---|Rifle/Automatic weapon", "ewrr--|Rifle", "ewrl--|Light machine gun", "ewrh--|Heavy machine gun", "ewz---|Grenade launcher",
			"ewzl--|Grenade launcher light", "ewzm--|Grenade launcher medium", "ewzh--|Grenade launcher heavy", "ewo---|Mortar", "ewol--|Mortar light", "ewom--|Mortar medium", "ewoh--|Mortar heavy",
			"ewh---|Howitzer", "ewhl--|Howitzer light", "ewhls-|Howitzer light self-propelled", "ewhm--|Howitzer medium", "ewhms-|Howitzer medium self-propelled", "ewhh--|Howitzer heavy",
			"ewhhs-|Howitzer heavy self-propelled", "ewg---|Anti-tank gun", "ewgl--|Anti-tank gun light", "ewgm--|Anti-tank gun medium", "ewgh--|Anti-tank gun heavy",
			"ewgr--|Anti-tank gun recoilless", "ewd---|Direct fire gun", "ewdl--|Direct fire gun light", "ewdld-|Direct fire gun light self-propelled", "ewdm--|Direct fire gun medium",
			"ewdmd-|Direct fire gun medium self-propelled", "ewdh--|Direct fire gun heavy", "ewdhd-|Direct fire gun heavy self-propelled", "ewa---|Air defense gun", "ewal--|Air defense gun light",
			"ewam--|Air defense gun medium", "ewah--|Air defense gun heavy", "ev----|Ground vehicle", "eva---|Armored vehicle", "evat--|Tank", "evatl-|Tank light", "evatlr|Tank light recovery",
			"evatm-|Tank medium", "evatmr|Tank medium recovery", "evath-|Tank heavy", "evathr|Tank heavy recovery", "evaa--|Armored personnel carrier", "evaar-|Armored personnel carrier recovery",
			"evai--|Armored infantry", "evac--|C2V/ACV", "evas--|Combat service support vehicle", "eval--|Light armored vehicle", "evu---|Utility vehicle", "evub--|Bus", "evus--|Semi",
			"evusl-|Semi light", "evusm-|Semi medium", "evush-|Semi heavy", "evul--|Limited cross-country truck", "evux--|Cross-country truck", "evur--|Water craft", "evut--|Tow truck",
			"evutl-|Tow truck light", "evuth-|Tow truck heavy", "evua--|Ambulance", "evuaa-|Armored ambulance", "eve---|Engineer vehicle", "eveb--|Bridge", "evee--|Earthmover",
			"evec--|Construction vehicle", "evem--|Mine laying vehicle", "evemv-|Armored carrier with volcano", "eveml-|Truck mounted with volcano", "evea--|Mine clearing vehicle",
			"eveaa-|Armored mounted mine clearing vehicle", "eveat-|Trailer mounted mine clearing vehicle", "eved--|Dozer", "eveda-|Armored dozer", "eves--|Armored assault",
			"ever--|Armored engineer recon vehicle (AREV)", "eveh--|Backhoe", "evef--|Ferry transporter", "evt---|Train locomotive", "evc---|Civilian vehicle", "evca--|Automobile",
			"evcal-|Compact automobile", "evcam-|Midsize automobile", "evcah-|Sedan automobile", "evco--|Open-Bed truck", "evcol-|Pickup open-bed truck", "evcom-|Small open-bed truck",
			"evcoh-|Large open-bed truck", "evcm--|Multiple passenger vehicle", "evcml-|Van multiple passenger vehicle", "evcmm-|Small bus multiple passenger vehicle",
			"evcmh-|Large bus multiple passenger vehicle", "evcu--|Utility vehicle", "evcul-|Sport utility vehicle (SUV)", "evcum-|Small box truck", "evcuh-|Large box truck",
			"evcj--|Jeep type vehicle", "evcjl-|Small/Light jeep type vehicle", "evcjm-|Medium jeep type vehicle", "evcjh-|Large/Heavy jeep type vehicle",
			"evct--|Tractor Trailer Truck with box trailer", "evctl-|Small/Light Tractor Trailer Truck with box trailer", "evctm-|Medium Tractor Trailer Truck with box trailer",
			"evcth-|Large/Heavy Tractor Trailer Truck with box trailer", "evcf--|Tractor Trailer Truck with flatbed trailer", "evcfl-|Small/Light Tractor Trailer Truck with flatbed trailer",
			"evcfm-|Medium Tractor Trailer Truck with flatbed trailer", "evcfh-|Large/Heavy Tractor Trailer Truck with flatbed trailer", "evm---|Pack animal(s)", "evs---|Missile support vehicle",
			"evst--|Missile support vehicle transloader", "evsr--|Missile support vehicle transporter", "evsc--|Missile support vehicle crane/loading device",
			"evsp--|Missile support vehicle propellant transporter", "evsw--|Missile support vehicle warhead transporter", "es----|Sensor", "esr---|Radar", "ese---|Emplaced sensor",
			"ex----|Special equipment", "exi---|Improvised explosive device (IED)", "exl---|Laser", "exn---|CBRN equipment", "exf---|Flame thrower", "exm---|Land mines", "exmc--|Claymore",
			"exml--|Less than lethal", "i-----|Installation", "ir----|Raw material production/storage", "irm---|Mine", "irp---|Petroleum/Gas/Oil", "irn---|CBRN", "irnb--|Biological",
			"irnc--|Chemical", "irnn--|Nuclear", "ip----|Processing facility", "ipd---|Decontamination", "ie----|Equipment manufacture", "iu----|Service reseach utility facility",
			"iur---|Technological research facility", "iut---|Telecommunications facility", "iue---|Electric power facility", "iuen--|Nuclear plant", "iued--|Dam", "iuef--|Fossil fuel",
			"iup---|Public water serivces", "im----|Military material facility", "imf---|Nuclear energy", "imfa--|Atomic energy reactor", "imfp--|Nuclear material production", "imfpw-|Weapons grade",
			"imfs--|Nuclear material storage", "ima---|Aircraft production and assembly", "ime---|Ammunition and explosives production", "img---|Armament productions",
			"imv---|Military vehicle production", "imn---|Engineering equipment production", "imnb--|Bridge", "imc---|Chemical and biological warfare production", "ims---|Ship construction",
			"imm---|Missile and space system production", "ig----|Government leadership", "ib----|Military base/facility", "iba---|Airport/Airbase", "ibn---|Seaport/Naval base",
			"it----|Transport facility", "ix----|Medical facility", "ixh---|Hospital"

	};
	public static final List<String> groundCodesList = Arrays.asList(SIDCCodes.groundCodesArray);

}
