/**
 * Note: This license has also been called the “Simplified BSD License” and the “FreeBSD License”.
 *
 * Copyright 2024-2026 UNIITY POC: Volker Voß, Federal Armed Forces of Germany
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSEnARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 */
package de.bundeswehr.uniity.sedapexpress.utils;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.util.Arrays;

import javax.crypto.KeyAgreement;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.crypto.generators.Argon2BytesGenerator;
import org.bouncycastle.crypto.params.Argon2Parameters;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import de.bundeswehr.uniity.sedapexpress.utils.EncryptionUtils.AESKeyLength;

/**
 * Some utils for a Eliptic curves Diffie-Hellmann key exchange
 * 
 * @author Volker Voß
 *
 */
public class ECDHUtils {

	static {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}

	/**
	 * Generates a key pair for the Elliptic-Curves-Diffie-Hellman-Merkle process
	 *
	 * @return Key pair
	 *
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws InvalidAlgorithmParameterException
	 */
	public static KeyPair generateKeyPair() throws NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException {

		KeyPairGenerator clientKeyPairGenerator = KeyPairGenerator.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME);
		clientKeyPairGenerator.initialize(new ECGenParameterSpec("brainpoolP256r1"));

		return clientKeyPairGenerator.generateKeyPair();
	}

	/**
	 * Calculates the shared secret key
	 *
	 * @param ownSecretKey          The own secret key
	 * @param otherPublicKey        The public key of the other side
	 * @param keyLengthSharedSecret The desired bit length of the shared secret key
	 * 
	 * @return the shared secret key
	 *
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 */
	public static byte[] getSharedSecretKey(PrivateKey ownSecretKey, PublicKey otherPublicKey, AESKeyLength keyLengthSharedSecret)
			throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException {

		KeyAgreement serverKeyAgreement = KeyAgreement.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME);
		serverKeyAgreement.init(ownSecretKey);
		serverKeyAgreement.doPhase(otherPublicKey, true);

		return new SecretKeySpec(serverKeyAgreement.generateSecret(), 0, keyLengthSharedSecret.getIntValue() / 8, "PBKDF2WithHmacSHA256").getEncoded();
	}

	/**
	 * Calculates the shared secret key using ECDH and derives a key of the
	 * requested length using Argon2id.
	 *
	 * @param ownSecretKey          The own private key
	 * @param otherPublicKey        The public key of the other side
	 * @param keyLengthSharedSecret The desired bit length of the shared secret key
	 * @param salt                  A cryptographically secure random salt
	 *
	 * @return The derived shared secret key
	 *
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 */
	public static byte[] getSharedSecretKey(PrivateKey ownSecretKey, PublicKey otherPublicKey, AESKeyLength keyLengthSharedSecret, byte[] salt)
			throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException {

		KeyAgreement keyAgreement = KeyAgreement.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME);

		keyAgreement.init(ownSecretKey);
		keyAgreement.doPhase(otherPublicKey, true);

		byte[] sharedSecret = keyAgreement.generateSecret();

		Argon2Parameters parameters = new Argon2Parameters.Builder(Argon2Parameters.ARGON2_id).withSalt(salt).withIterations(3).withMemoryAsKB(65536).withParallelism(1).build();

		Argon2BytesGenerator generator = new Argon2BytesGenerator();
		generator.init(parameters);

		byte[] derivedKey = new byte[keyLengthSharedSecret.getIntValue() / 8];

		generator.generateBytes(sharedSecret, derivedKey);

		Arrays.fill(sharedSecret, (byte) 0);

		return derivedKey;
	}

}
