/**
 * Note: This license has also been called the “Simplified BSD License” and the “FreeBSD License”.
 *
 * Copyright 2024-2026 UNIITY POC: Volker Voß, Federal Armed Forces of Germany
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 */
package de.bundeswehr.uniity.sedapexpress.controls;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ListView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Tooltip;
import javafx.scene.input.Clipboard;
import javafx.scene.input.DataFormat;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

/**
 * Represents or provides the sedapexpress logging area functionality.
 *
 * @author Volker Voß
 *
 */
public class SEDAPExpressLoggingArea extends GridPane {

	private final ListView<String> textList = new ListView<>();

	private final ToggleButton startStopLoggingButton;

	private final boolean pause = false;

	@FXML
	public String text;

	@FXML
	public int maxLogEntries = 50;

	@FXML
	public int deleteSize = 20;

	private boolean selected;

	/**
	 * Returns the text.
	 * @return the text
	 */
	@FXML
	public String getText() {
		return this.text;
	}

	/**
 * Sets the text.
	 * @param text the text to set
	 */
	public void setText(final String text) {
		this.text = text;
	}

	/**
 * Returns the max log entries.
	 * @return the maxLogEntries
	 */
	public int getMaxLogEntries() {
		return this.maxLogEntries;
	}

	/**
 * Sets the max log entries.
	 * @param maxLogEntries the maxLogEntries to set
	 */
	public void setMaxLogEntries(final int maxLogEntries) {
		this.maxLogEntries = maxLogEntries;
	}

	/**
 * Returns the delete size.
	 * @return the deleteSize
	 */
	public int getDeleteSize() {
		return this.deleteSize;
	}

	/**
 * Sets the delete size.
	 * @param deleteSize the deleteSize to set
	 */
	public void setDeleteSize(final int deleteSize) {
		this.deleteSize = deleteSize;
	}

	/**
	 * Creates a sedapexpress logging area instance.
	 */
	public SEDAPExpressLoggingArea() {

		final Button saveButton = new Button("Save");
		saveButton.setOnAction(x -> {
			final FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save logging to a file");
			fileChooser.setInitialDirectory(new File("."));
			fileChooser.getExtensionFilters().add(new ExtensionFilter("Logging files", "*.txt"));

			final File logFile = fileChooser.showSaveDialog(null);

			if (logFile != null) {

				try (BufferedWriter out = new BufferedWriter(new FileWriter(logFile, false))) {

					for (final String entrie : this.textList.getItems()) {
						out.write(entrie);
						out.newLine();
					}

				} catch (final IOException e) {

				}
			}
		});

		final Button clipboardButton = new Button("Clipboard");
		clipboardButton.setOnAction(x -> {
			final StringBuilder allText = new StringBuilder();
			this.textList.getItems().forEach(allText::append);
			final HashMap<DataFormat, Object> data = new HashMap<>();
			data.put(DataFormat.PLAIN_TEXT, allText.toString());
			Clipboard.getSystemClipboard().setContent(data);
		});

		final Button clearButton = new Button("Clear");
		clearButton.setOnAction(x -> {
			this.textList.getItems().clear();
		});

		this.startStopLoggingButton = new ToggleButton("Stop logging");
		this.startStopLoggingButton.selectedProperty().addListener((s, o, n) -> {
			this.selected = n;
		});

		setPrefWidth(Region.USE_COMPUTED_SIZE);
		setPrefHeight(Region.USE_COMPUTED_SIZE);
		setMaxWidth(Double.MAX_VALUE);
		setMaxHeight(Double.MAX_VALUE);

		setVgap(5);
		this.textList.setPrefHeight(50);

		final ButtonBar buttonBar = new ButtonBar();
		buttonBar.getButtons().add(saveButton);
		buttonBar.getButtons().add(clipboardButton);
		buttonBar.getButtons().add(clearButton);
		buttonBar.getButtons().add(this.startStopLoggingButton);

		add(this.textList, 0, 0, 1, 1);
		add(buttonBar, 0, 1, 1, 1);

		final ColumnConstraints colContrains = new ColumnConstraints();
		colContrains.setMaxWidth(Double.MAX_VALUE);
		colContrains.setHgrow(Priority.ALWAYS);

		final RowConstraints rowContrains = new RowConstraints();
		rowContrains.setMaxHeight(Double.MAX_VALUE);
		rowContrains.setVgrow(Priority.ALWAYS);

		getColumnConstraints().add(colContrains);
		getRowConstraints().add(rowContrains);
	}

	/**
 * Performs the log operation.
	 *
	 * @param logText value for log text
	 */
	public void log(final String logText) {

		if (this.selected || (logText == null)) {
			return;
		}

		// System.out.println(logText);
		if (Platform.isFxApplicationThread()) {
			if (this.textList.getItems().size() >= this.maxLogEntries) {
				this.textList.getItems().remove(0, this.deleteSize);
			}
			this.textList.getItems().add(logText.trim());
			this.textList.scrollTo(this.textList.getItems().size());
		} else {
			Platform.runLater(() -> {
				if (this.textList.getItems().size() >= this.maxLogEntries) {
					this.textList.getItems().remove(0, this.deleteSize);
				}
				this.textList.getItems().add(logText.trim());
				this.textList.scrollTo(this.textList.getItems().size());
			});
		}
	}

	/**
	 * Performs the new line operation.
	 */
	public void newLine() {
		if (this.pause) {
			return;
		}
		this.textList.getItems().add("\n");
	}

	/**
	 * Performs the clear log operation.
	 */
	public void clearLog() {
		this.textList.getItems().clear();
	}

	/**
	 * Sets the tooltip text.
	 * @param text value for text
	 */
	public void setTooltipText(final String text) {
		this.textList.setTooltip(new Tooltip(text));
	}

	/**
	 * Performs the deactivate logging operation.
	 */
	public void deactivateLogging() {
		this.startStopLoggingButton.setSelected(true);
		this.selected = true;
	}

	/**
	 * Performs the activate logging operation.
	 */
	public void activateLogging() {
		this.startStopLoggingButton.setSelected(false);
		this.selected = false;
	}

	/**
	 * Indicates whether the logging active condition is met.
	 * @return {@code true} if the condition is satisfied; otherwise {@code false}.
	 */
	public boolean isLoggingActive() {

		return !this.selected;
	}

}
