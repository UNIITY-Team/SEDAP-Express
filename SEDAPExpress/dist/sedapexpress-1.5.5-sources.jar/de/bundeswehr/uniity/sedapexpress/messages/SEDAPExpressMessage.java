/**
 * Note: This license has also been called the “Simplified BSD License” and the “FreeBSD License”.
 *
 * Copyright 2024-2026 UNIITY POC: Volker Voß, Federal Armed Forces of Germany
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 */
package de.bundeswehr.uniity.sedapexpress.messages;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.RecordComponent;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import de.bundeswehr.uniity.sedapexpress.messages.COMMAND.PowerState;

/**
 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
 * 
 * @author Volker Voß
 */
public abstract class SEDAPExpressMessage implements Comparable<SEDAPExpressMessage>, Serializable {

	private static final long serialVersionUID = 6080930577547088687L;

	protected static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	static {
		SEDAPExpressMessage.logger.setLevel(Level.ALL);
	}

	/**
	 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
	 */
	public enum MessageType {

		ACKNOWLEDGE, COMMAND, CONTACT, POINT, EMISSION, GENERIC, GRAPHIC, HEARTBEAT, KEYEXCHANGE, METEO, OWNUNIT, RESEND, STATUS, TEXT, TIMESYNC;

		/**
		 * Resolves the corresponding value from the supplied representation.
		 * 
		 * @param type value for type
		 * @return the result of the operation
		 */
		public static MessageType valueOfMessageType(String type) {
			return MessageType.valueOf(type.toUpperCase());
		}
	}

	/**
	 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
	 */
	public enum DeleteFlag {

		FALSE, TRUE;

		/**
		 * Returns the value of delete flag.
		 * 
		 * @param flag value for flag
		 * @return the value of delete flag
		 */
		public static DeleteFlag getValueOfDeleteFlag(boolean flag) {

			if (flag)
				return TRUE;
			else
				return FALSE;
		}
	}

	/**
	 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
	 */
	public enum DataEncoding {

		NONE, BASE64;
	}

	/**
	 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
	 */
	public enum Classification {

		None('-'), Public('P'), Unclas('U'), Restricted('R'), Confidential('C'), Secret('S'), Top_Secret('T');

		char classification;

		/**
		 * Returns the classification.
		 * 
		 * @return the classification
		 */
		public char getClassification() {
			return this.classification;
		}

		Classification(char classification) {
			this.classification = classification;
		}

		/**
		 * Returns the value of classification.
		 * 
		 * @param classification value for classification
		 * @return the value of classification
		 */
		public static Classification getValueOfClassification(char classification) {

			return switch (classification) {
			case '-' -> Classification.None;
			case 'P', 'p' -> Classification.Public;
			case 'U', 'u' -> Classification.Unclas;
			case 'R', 'r' -> Classification.Restricted;
			case 'C', 'c' -> Classification.Confidential;
			case 'S', 's' -> Classification.Secret;
			case 'T', 't' -> Classification.Top_Secret;
			default -> Classification.None;
			};
		}

		/**
		 * Returns the textual representation of this instance.
		 * 
		 * @return the result of the operation
		 */
		@Override
		public String toString() {
			return String.valueOf(this.classification);
		}

	}

	public static final Classification NATO_Restricted = Classification.Restricted;
	public static final Classification NATO_Confidential = Classification.Confidential;
	public static final Classification NATO_Secret = Classification.Secret;
	public static final Classification COSMIC_Top_Secret = Classification.Top_Secret;

	public static final Classification EU_Restricted = Classification.Restricted;
	public static final Classification EU_Confidential = Classification.Confidential;
	public static final Classification EU_Secret = Classification.Secret;
	public static final Classification EU_Top_Secret = Classification.Top_Secret;

	public static final Classification Restreint_UE = Classification.Restricted;
	public static final Classification Confidentiel_UE = Classification.Confidential;
	public static final Classification Secret_UE = Classification.Secret;
	public static final Classification Tres_Secret_UE = Classification.Top_Secret;

	public static final Classification Keine = Classification.None;
	public static final Classification Oeffentlich = Classification.Public;
	public static final Classification Offen = Classification.Unclas;
	public static final Classification VS_NFD = Classification.Restricted;
	public static final Classification VS_Vertraulich = Classification.Confidential;
	public static final Classification Geheim = Classification.Secret;
	public static final Classification Streng_Geheim = Classification.Top_Secret;

	/**
	 * Defines the common SEDAP-Express message header, parsing and serialization behavior.
	 */
	public enum Acknowledgement {

		FALSE, TRUE;
	}

	public static final HexFormat HexFormater = HexFormat.of().withUpperCase();

	public static final NumberFormat NumberFormatter = new DecimalFormat("##.############", DecimalFormatSymbols.getInstance(Locale.ENGLISH));

	public static final Pattern NAME_MATCHER = Pattern.compile("^[a-zA-Z]+$"); // Name
	public static final Pattern NUMBER_MATCHER = Pattern.compile("^[0-7][0-9A-F]$"); // Number 00-7F
	public static final Pattern TIME_MATCHER = Pattern.compile("^[A-Fa-f0-9]{8,16}$"); // Time
	public static final Pattern MAC_MATCHER = Pattern.compile("^(?:[A-Fa-f0-9]{8}|[A-Fa-f0-9]{32}|[A-Fa-f0-9]{64})$"); // Supported 32/128/256-bit MAC values
	public static final Pattern CLASSIFICATION_MATCHER = Pattern.compile("^[P,U,R,C,S,T]{1}$");
	public static final Pattern HEXNUMBER_MATCHER = Pattern.compile("^[A-Fa-f0-9]+$");
	public static final Pattern TEXTTYPE_MATCHER = Pattern.compile("^0?[0-4]$"); // Text type (one or two decimal digits)

	public static final Pattern DOUBLE_MATCHER = Pattern.compile("^-?\\d+.?\\d*$"); // Double
	public static final Pattern POSITIVE_DOUBLE_MATCHER = Pattern.compile("^\\d+.?\\d*$"); // Double
	public static final Pattern DOUBLE_LIST_MATCHER = Pattern.compile("^[\\d.?\\d?#]*$"); // Double
	public static final Pattern POS_INTEGER_MATCHER = Pattern.compile("^\\d+$"); // Positive Integer
	public static final Pattern INTEGER_MATCHER = Pattern.compile("^-?\\d+$"); // Integer
	public static final Pattern BIGINTEGER_MATCHER = Pattern.compile("^([A-Fa-f0-9][A-Fa-f0-9])+$"); // Hexadecimal BigInteger
	public static final Pattern YES_NO_FLAG_MATCHER = Pattern.compile("^TRUE$|^FALSE$");
	public static final Pattern ON_OFF_FLAG_MATCHER = Pattern.compile("^ON$|^OFF$");

	public static final Pattern BEARING_MATCHER = Pattern.compile("^(\\d+\\.?\\d*|[012]\\d\\d\\.\\d*|3[0-5]\\d\\\\.\\d*)$"); // 000.00-359.999
	public static final Pattern SIDC_MATCHER = Pattern.compile("^[a-zA-Z-]{15}$"); // SIDC
	public static final Pattern MMSI_MATCHER = SEDAPExpressMessage.INTEGER_MATCHER; // Integer
	public static final Pattern ICAO_MATCHER = Pattern.compile("^[A-F0-9]{1,6}$"); // ICAO
	public static final Pattern SOURCE_MATCHER = Pattern.compile("^[R,A,I,S,E,O,Y,M]+$"); // Source type
	public static final Pattern CMDTYPE_MATCHER = Pattern.compile("^[A-Fa-f0-9]+$"); // Command type
	public static final Pattern GRAPHICTYPE_MATCHER = Pattern.compile("^(?:0[0-9A-Ba-b]|[0-9])$"); // Graphic type (hexadecimal)
	public static final Pattern RGBA_MATCHER = Pattern.compile("^[0-9A-F]{6,8}$"); // RGBA Format
	public static final Pattern TECSTATUS_MATCHER = Pattern.compile("^[0-5]$"); // TecStatus
	public static final Pattern OPSSTATUS_MATCHER = Pattern.compile("^[0-4]$"); // OpsStatus
	public static final Pattern PERCENT_MATCHER = Pattern.compile("^([A-Za-z0-9]*#(100(\\\\.0+)?|(\\d{1,2}(.\\d+)*))#*)+$"); // Percent
	public static final Pattern DATA_ENCODING_MATCHER = Pattern.compile("^BASE64$|^NONE$");
	public static final Pattern CONTENT_TYPE_MATCHER = Pattern.compile("^SEDAP$|^ASCII$|^NMEA$|^XML$|^JSON$|^BINARY$");

	/**
	 * Indicates whether the matches pattern condition is satisfied.
	 * 
	 * @param pattern value for pattern
	 * @param value   value for value
	 * @return {@code true} if the condition is satisfied; otherwise {@code false}.
	 */
	public static boolean matchesPattern(Pattern pattern, String value) {
		return pattern.matcher(value).matches();
	}

	private Byte number;

	private Long time;

	private String sender;

	private Classification classification;

	private Acknowledgement acknowledgement;

	private String mac;

	/** Original serialized input retained for MAC verification without canonical re-serialization. */
	private transient String receivedWireText;
	private transient String receivedCanonicalText;

	/**
	 * Returns the number.
	 * 
	 * @return the number
	 */
	public Byte getNumber() {
		return this.number;
	}

	/**
	 * Sets the number.
	 * 
	 * @param number value for number
	 */
	public void setNumber(Byte number) {
		this.number = number;
	}

	/**
	 * Returns the time.
	 * 
	 * @return the time
	 */
	public Long getTime() {
		return this.time;
	}

	/**
	 * Sets the time.
	 * 
	 * @param time value for time
	 */
	public void setTime(Long time) {
		this.time = time;
	}

	/**
	 * Returns the sender.
	 * 
	 * @return the sender
	 */
	public String getSender() {
		return this.sender;
	}

	/**
	 * Sets the sender.
	 * 
	 * @param sender value for sender
	 */
	public void setSender(String sender) {
		this.sender = sender;
	}

	/**
	 * Returns the classification.
	 * 
	 * @return the classification
	 */
	public Classification getClassification() {
		return this.classification;
	}

	/**
	 * Sets the classification.
	 * 
	 * @param classification value for classification
	 */
	public void setClassification(Classification classification) {
		this.classification = classification;
	}

	/**
	 * Returns the acknowledgement.
	 * 
	 * @return the acknowledgement
	 */
	public Acknowledgement getAcknowledgement() {
		return this.acknowledgement;
	}

	/**
	 * Sets the acknowledgement.
	 * 
	 * @param acknowledgement value for acknowledgement
	 */
	public void setAcknowledgement(Acknowledgement acknowledgement) {
		this.acknowledgement = acknowledgement;
	}

	/**
	 * Returns the mac.
	 * 
	 * @return the mac
	 */
	public String getMAC() {
		return this.mac;
	}

	/**
	 * Returns the exact wire text used to deserialize this instance, or {@code null} if it was created locally.
	 *
	 * @return original serialized input, without modification
	 */
	public final String getReceivedWireText() {
		return this.receivedWireText;
	}

	/**
	 * Returns the canonical serialization captured immediately after deserialization.
	 * It allows MAC verification to detect later field modifications without changing the message.
	 *
	 * @return canonical parsed representation, or {@code null} for locally created messages
	 */
	public final String getReceivedCanonicalText() {
		return this.receivedCanonicalText;
	}

	/**
	 * Sets the mac.
	 * 
	 * @param mac value for mac
	 */
	public void setMAC(String mac) {
		this.mac = mac;
	}

	/**
	 * Returns the message type.
	 * 
	 * @return the message type
	 */
	public MessageType getMessageType() {
		return MessageType.valueOfMessageType(this.getClass().getSimpleName());
	}

	/**
	 * Returns the result of the compare to operation.
	 * 
	 * @param otherMessage value for other message
	 * @return the result of the operation
	 */
	@Override
	public int compareTo(final SEDAPExpressMessage otherMessage) {

		return this.getClass().getSimpleName().compareTo(otherMessage.getClass().getSimpleName());
	}

	/**
	 * Returns the canonical wire representation used for message equality.
	 * Empty fields and fields omitted because they have their protocol default
	 * therefore compare equal. A null result indicates an invalid/incomplete
	 * object whose serializer cannot produce a wire representation.
	 */
	/**
	 * Returns the canonical serialized representation used for equality and hashing.
	 * 
	 * @return canonical message text, or {@code null} if serialization fails
	 */
	protected final String equalityKey() {
		try {
			return toString();
		} catch (RuntimeException exception) {
			return null;
		}
	}

	/**
	 * Compares this instance with the specified object.
	 * 
	 * @param obj value for obj
	 * @return {@code true} if the condition is satisfied; otherwise {@code false}.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		String thisKey = equalityKey();
		String otherKey = ((SEDAPExpressMessage) obj).equalityKey();
		return thisKey != null && thisKey.equals(otherKey);
	}

	/**
	 * Returns the hash code for this instance.
	 * 
	 * @return the result of the check
	 */
	@Override
	public int hashCode() {
		String key = equalityKey();
		return (key != null) ? key.hashCode() : System.identityHashCode(this);
	}

	/**
	 * If one is using for instance a ComboBox with the available classifications,
	 * this method can be used to get the matching classification depending on the
	 * selected index.
	 *
	 * @param selectedIndex of for instance a List or a ComboBox
	 * @return classification code
	 */
	public static Classification getClassificationFromIndex(final int selectedIndex) {

		return switch (selectedIndex) {
		case 0 -> Classification.Public;
		case 1 -> Classification.Unclas;
		case 2 -> Classification.Restricted;
		case 3 -> Classification.Confidential;
		case 4 -> Classification.Secret;
		case 5 -> Classification.Top_Secret;
		default -> Classification.None;
		};
	}

	/**
	 * Returns the higher classification of two given classifications.
	 *
	 * @param classification1 first classification code
	 * @param classification2 second classification code
	 * @return the higher classification
	 */
	public static Classification getMaxClassification(final Classification classification1, final Classification classification2) {

		return switch (classification1) {
		case None, Public -> classification2;
		case Unclas -> switch (classification2) {
		case Public -> classification1;
		default -> classification2;
		};
		case Restricted -> switch (classification2) {
		case Public, Unclas -> classification1;
		default -> classification2;
		};
		case Confidential -> switch (classification2) {
		case Public, Unclas, Restricted -> classification1;
		default -> classification2;
		};
		case Secret -> switch (classification2) {
		case Public, Unclas, Restricted, Confidential -> classification1;
		default -> classification2;
		};
		case Top_Secret -> classification1;
		default -> classification1;
		};
	}

	/**
	 * Returns the lower classification of two given classifications.
	 *
	 * @param classification1 first classification code
	 * @param classification2 second classification code
	 * @return the lower classification
	 */
	public static Classification getMinClassification(final Classification classification1, final Classification classification2) {

		return switch (classification1) {
		case Public -> classification1;
		case Unclas -> switch (classification2) {
		case Public -> classification2;
		default -> classification1;
		};
		case Restricted -> switch (classification2) {
		case Public, Unclas -> classification2;
		default -> classification1;
		};
		case Confidential -> switch (classification2) {
		case Public, Unclas, Restricted -> classification2;
		default -> classification1;
		};
		case Secret -> switch (classification2) {
		case Public, Unclas, Restricted, Confidential -> classification2;
		default -> classification1;
		};
		case Top_Secret -> classification2;
		default -> classification2;
		};
	}

	/**
	 * Returns the textual representation of the given classification code.
	 *
	 * @param classification value for classification
	 * @return the matching textual representation
	 */
	public static String getClassificationFullNameFromClassification(final Classification classification) {

		return switch (classification) {
		case Public -> "public";
		case Unclas -> "unclas";
		case Restricted -> "restricted";
		case Confidential -> "confidential";
		case Secret -> "secret";
		case Top_Secret -> "top secret";
		default -> "-";
		};
	}

	/**
	 * Returns the classification code from a given textual representation
	 *
	 * @param classificationFullName Textual classification
	 * @return the matching classification code
	 */
	public static Classification getClassificationFromFullName(final String classificationFullName) {

		return switch (classificationFullName.trim().toUpperCase().replace("NATO", "").replace("EU", "").replace(" ", "")) {
		case "OEFFENTLICH", "PUBLIC" -> Classification.Public;
		case "OFFEN", "UNCLAS" -> Classification.Unclas;
		case "VS-NFD", "RESTRICTED" -> Classification.Restricted;
		case "VS-VERTRAULICH", "CONFIDENTIAL" -> Classification.Confidential;
		case "GEHEIM", "VS-GEHEIM", "SECRET" -> Classification.Secret;
		case "STRENGGEHEIM", "VS-STRENGGEHEIM", "TOP SECRET" -> Classification.Top_Secret;
		default -> Classification.None;
		};
	}

	/**
	 * Compares two classifications with each other and returns whether the given
	 * classification is within the maximum permissible classification range.
	 *
	 * @param classification    classification to text
	 * @param maxClassification Maximal permitted classification
	 * @return true=classification permitted, false=classification NOT permitted
	 */
	public static boolean isClassificationIncluded(final Classification classification, final Classification maxClassification) {

		return switch (classification) {
		case None -> false;
		case Public -> true; // Always permitted
		case Unclas -> (maxClassification == Classification.Unclas) || (maxClassification == Classification.Restricted) || (maxClassification == Classification.Confidential)
				|| (maxClassification == Classification.Secret) || (maxClassification == Classification.Top_Secret);
		case Restricted -> (maxClassification == Classification.Restricted) || (maxClassification == Classification.Confidential) || (maxClassification == Classification.Secret)
				|| (maxClassification == Classification.Top_Secret);
		case Confidential -> (maxClassification == Classification.Confidential) || (maxClassification == Classification.Secret) || (maxClassification == Classification.Top_Secret);
		case Secret -> (maxClassification == Classification.Secret) || (maxClassification == Classification.Top_Secret);
		case Top_Secret -> maxClassification == Classification.Top_Secret;
		default -> throw new IllegalArgumentException("Unexpected value: " + classification);
		};
	}

	/**
	 * Split a serialized SEDAP-Express message into a list of values.
	 *
	 * @param message SEDAP-Express message
	 * @return Array with the content of the SEDAP-Express message
	 */
	public static List<String> splitMessage(final String message) {

		final var sb = new StringBuilder();
		final var words = new ArrayList<String>();
		words.ensureCapacity(6); // Minimal size
		final var strArray = message.toCharArray();
		for (final char c : strArray) {
			if (c == ';') {
				if (sb.length() != 0) {
					words.add(sb.toString());
					sb.delete(0, sb.length());
				} else {
					words.add("");
				}
			} else {
				sb.append(c);
			}
		}

		if (sb.length() != 0) {
			words.add(sb.toString());
		} else {
			words.add("");
		}

		return words;
	}

	/**
	 * Splits a #-list in a serialized SEDAP-Express message into a list of string
	 * values.
	 *
	 * @param list #-list
	 * @return Array with the content of the #-list
	 */
	public static List<String> splitStringDataHashTag(final String list) {

		final var sb = new StringBuilder();
		final var words = new ArrayList<String>();
		final var strArray = list.toCharArray();
		for (final char c : strArray) {
			if (c == '#') {
				if (sb.length() != 0) {
					words.add(sb.toString());
					sb.delete(0, sb.length());
				} else {
					words.add(null);
				}
			} else {
				sb.append(c);
			}
		}

		if (sb.length() != 0) {
			words.add(sb.toString());
		} else {
			words.add(null);
		}

		return words;
	}

	/**
	 * Splits a #-list in a serialized SEDAP-Express message into a list of integer
	 * values.
	 *
	 * @param list #-list
	 * @return Array with the content of the #-list
	 */
	public static List<Integer> splitIntegerDataHashTag(final String list) {

		final var sb = new StringBuilder();
		final var words = new ArrayList<Integer>();
		final var strArray = list.toCharArray();
		for (final char c : strArray) {
			if (c == '#') {
				if (sb.length() != 0) {
					words.add(Integer.valueOf(sb.toString()));
					sb.delete(0, sb.length());
				} else {
					words.add(null);
				}
			} else {
				sb.append(c);
			}
		}

		if (sb.length() != 0) {
			words.add(Integer.valueOf(sb.toString()));
		} else {
			words.add(null);
		}

		return words;
	}

	/**
	 * Splits a #-list in a serialized SEDAP-Express message into a list of double
	 * values.
	 *
	 * @param list #-list
	 * @return Array with the content of the #-list
	 */
	public static List<Double> splitDoubleDataHashTag(final String list) {

		final var sb = new StringBuilder();
		final var words = new ArrayList<Double>();
		final var strArray = list.toCharArray();
		for (final char c : strArray) {
			if (c == '#') {
				if (sb.length() != 0) {
					words.add(Double.valueOf(sb.toString()));
					sb.delete(0, sb.length());
				} else {
					words.add(null);
				}
			} else {
				sb.append(c);
			}
		}

		if (sb.length() != 0) {
			words.add(Double.valueOf(sb.toString()));
		} else {
			words.add(null);
		}

		return words;
	}

	/**
	 * Splits a #-list in a serialized SEDAP-Express message into a list of double
	 * arrays.
	 *
	 * @param list #-list
	 * @return Array with the content of the #-list
	 */
	public static List<double[]> splitDoubleArrayDataHashTag(final String list) {

		final var sb = new StringBuilder();
		final var words = new ArrayList<double[]>();
		final var strArray = list.toCharArray();
		for (final char c : strArray) {
			if (c == '#') {
				if (sb.length() != 0) {
					words.add(SEDAPExpressMessage.splitDoubleData(sb.toString()));
					sb.delete(0, sb.length());
				} else {
					words.add(null);
				}
			} else {
				sb.append(c);
			}
		}

		// Last element
		if (sb.length() != 0) {
			words.add(SEDAPExpressMessage.splitDoubleData(sb.toString()));
		} else {
			words.add(null);
		}

		return words;
	}

	/**
	 * Split a comma separated list of double values into an array
	 * 
	 * @param sb Comma separated list of double values
	 * @return Array of doubles
	 */
	protected static double[] splitDoubleData(String sb) {

		int count = 1;
		for (int i = 0; i < sb.length(); i++) {
			if (sb.charAt(i) == ',')
				count++;
		}

		double[] result = new double[count];

		int start = 0;
		int currentIdx = 0;

		for (int i = 0; i < sb.length(); i++) {
			if (sb.charAt(i) == ',') {
				result[currentIdx++] = Double.parseDouble(sb.substring(start, i));
				start = i + 1;
			}
		}
		// Last element
		result[currentIdx] = Double.parseDouble(sb.substring(start));

		return result;
	}

	/**
	 * Returns the string from list.
	 *
	 * @param list List of elements
	 * @return String with #-separated list elements
	 */
	public String getStringFromList(List<?> list) {

		StringBuilder str = new StringBuilder();
		list.forEach(freq -> str.append('#').append(freq));
		str.deleteCharAt(0);

		return str.toString();
	}

	/**
	 * Returns the result of the object to csv operation.
	 * 
	 * @param obj value for obj
	 * @return the result of the operation
	 */
	public static String objectToCSV(Object obj) {

		if (obj == null)
			return "";

		// Holt alle Record-Komponenten (Attribute) automatisch
		RecordComponent[] components = obj.getClass().getRecordComponents();

		if (components == null || components.length == 0) {
			return ""; // Für Records ohne Parameter (wie Restart)
		}

		return Arrays.stream(components).map(c -> {
			try {
				Object value = c.getAccessor().invoke(obj);

				if (value == null)
					return "";
				else if (value instanceof ArrayList<?> list) {
					return list.stream().map(arrayObj -> {
						double[] array = (double[]) arrayObj;
						return Arrays.stream(array).mapToObj(String::valueOf).collect(Collectors.joining(","));
					}).collect(Collectors.joining("#"));
				} else if (value instanceof PowerState ps) {
					return ps.name();
				} else if (value instanceof Long longValue) {
					return Long.toHexString(longValue).toUpperCase();
				} else if (value instanceof Double doubleValue) {
					return SEDAPExpressMessage.NumberFormatter.format(doubleValue).toUpperCase();
				} else if (value instanceof Float floatValue) {
					return SEDAPExpressMessage.NumberFormatter.format(floatValue).toUpperCase();
				}

				return String.valueOf(value);
			} catch (Exception e) {
				return "";
			}
		}).collect(Collectors.joining(";"));
	}

	/**
	 *
	 */
	private static final ConcurrentHashMap<String, Constructor<?>> messageNameToConstructor = new ConcurrentHashMap<>();
	static {

		final Class<?>[] paramTypes = new Class[] { Iterator.class };

		Arrays.asList(

				ACKNOWLEDGE.class, COMMAND.class, CONTACT.class, POINT.class, EMISSION.class, GENERIC.class, GRAPHIC.class, HEARTBEAT.class, TIMESYNC.class, KEYEXCHANGE.class, METEO.class,
				OWNUNIT.class, RESEND.class, STATUS.class, TEXT.class).forEach(clazz -> {
					try {
						SEDAPExpressMessage.messageNameToConstructor.put(clazz.getSimpleName(), clazz.getConstructor(paramTypes));
					} catch (NoSuchMethodException | SecurityException e) {
						e.printStackTrace();
					}
				});
	}

	static {
		System.out.println("""
					\n
				***************************************************
				***************************************************
				**   SEDAP-Express v1.5.5 (November 23th, 2026)  **
				**    Licensed under the BSD-2-clause License    **
				** (C)2024-2026, Federal Armed Forces of Germany **
				***************************************************
				***************************************************\n""");
	}

	/**
	 * Initializes the common SEDAP-Express message header.
	 *
	 * @param number          message sequence number
	 * @param time            message timestamp
	 * @param sender          sender identifier
	 * @param classification  information classification
	 * @param acknowledgement acknowledgement flag
	 * @param mac             message authentication code, or {@code null} when absent
	 */
	protected SEDAPExpressMessage(Byte number, Long time, String sender, Classification classification, Acknowledgement acknowledgement, String mac) {
		super();
		this.number = number;
		this.time = time;
		this.sender = sender;
		this.classification = classification;
		this.acknowledgement = acknowledgement;
		this.mac = mac;
	}

	/**
	 * Parses the common header fields from the remaining serialized message fields.
	 *
	 * @param message iterator positioned at the first common-header field
	 */
	protected SEDAPExpressMessage(Iterator<String> message) {

		try {

			String value;
			if (message.hasNext()) {
				value = message.next();
				if (value.isEmpty()) {
					SEDAPExpressMessage.logger.logp(Level.INFO, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"number\" is empty!", value);
				} else if (SEDAPExpressMessage.matchesPattern(SEDAPExpressMessage.NUMBER_MATCHER, value)) {
					this.number = Byte.parseByte(value, 16);
				} else if (!value.isBlank()) {
					SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"number\" contains invalid value!", value);
				}
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

			if (message.hasNext()) {
				value = message.next();
				if (value.isEmpty()) {
					SEDAPExpressMessage.logger.logp(Level.INFO, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"time\" is empty!", value);
				} else if (SEDAPExpressMessage.matchesPattern(SEDAPExpressMessage.TIME_MATCHER, value)) {
					this.time = Long.parseLong(value, 16);
				} else if (!value.isBlank()) {
					SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"time\" contains invalid value!", value);
				}
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

			if (message.hasNext()) {
				value = message.next();
				if (value.isBlank()) {
					SEDAPExpressMessage.logger.logp(Level.INFO, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"sender\" is empty!");
				} else {
					this.sender = value;
				}
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

			if (message.hasNext()) {
				String classChar = message.next().trim();
				if (!classChar.isBlank()) {
					this.classification = Classification.getValueOfClassification(classChar.charAt(0));
				}
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

			if (message.hasNext()) {
				value = message.next();
				if (SEDAPExpressMessage.matchesPattern(SEDAPExpressMessage.YES_NO_FLAG_MATCHER, value)) {
					this.acknowledgement = Acknowledgement.valueOf(value);
				} else if (value.isBlank()) {
					this.acknowledgement = Acknowledgement.FALSE;
				} else {
					SEDAPExpressMessage.logger.severe("Optional field \"acknowledgement\" invalid value: \"" + value + "\"");
				}
			} else if (this instanceof HEARTBEAT) {
				// incomplete message allowed
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

			if (message.hasNext()) {
				value = message.next();
				if (SEDAPExpressMessage.matchesPattern(SEDAPExpressMessage.MAC_MATCHER, value)) {
					this.mac = value;
				} else if (!value.isBlank()) {
					SEDAPExpressMessage.logger.logp(Level.INFO, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Optional field \"mac\" contains not a valid 32bit mac number!",
							value);
				}
			} else if (this instanceof HEARTBEAT) {
				// incomplete message allowed
			} else {
				SEDAPExpressMessage.logger.logp(Level.SEVERE, "SEDAPExpressMessage", "SEDAPExpressMessage(Iterator<String> message)", "Incomplete message!");
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/*
	 *
	 */
	protected SEDAPExpressMessage() {
		// abstract, hide constructor
	}

	/**
	 * Deserializes a SEDAP-Express message and return the matching concrete
	 * implementation object.
	 *
	 * @param receivedMessage serialized SEDAP-Message
	 *
	 * @return deserialized SEDAP-Message object
	 */
	public static SEDAPExpressMessage deserialize(String receivedMessage) {

		final Iterator<String> messageArray = SEDAPExpressMessage.splitMessage(receivedMessage).iterator();

		if (messageArray.hasNext()) {

			try {

				Constructor<?> constructor = SEDAPExpressMessage.messageNameToConstructor.get(messageArray.next());

				if (constructor != null) {
					SEDAPExpressMessage message = (SEDAPExpressMessage) constructor.newInstance(messageArray);
					message.receivedWireText = receivedMessage;
					message.receivedCanonicalText = message.toString();
					return message;
				} else {
					return null;
				}

			} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				SEDAPExpressMessage.logger.throwing("SEDAPExpressMessage", "deserialize(String receivedMessage)", e);
				return null;
			}

		} else {
			return null;
		}
	}

	/**
	 * Serializes a SEDAP-Express message and return a String object.
	 *
	 * @param message SEDAP-Message object
	 *
	 * @return SEDAP-Express message serialized as String object
	 */
	public static String serialize(SEDAPExpressMessage message) {
		return message.toString() + '\n';
	}

	protected StringBuilder serializeHeader() {

		StringBuilder result = new StringBuilder(this.getClass().getSimpleName()).append(';');

		if (this.number != null) {
			result.append(SEDAPExpressMessage.HexFormater.toHexDigits(this.number));
		}
		result.append(';');

		if (this.time != null) {
			result.append(SEDAPExpressMessage.HexFormater.toHexDigits(this.time, 12));
		}
		result.append(';');

		if (this.sender != null) {
			result.append(this.sender);
		}
		result.append(';');

		if (this.classification != null) {
			result.append(this.classification.toString());
		}
		result.append(';');

		if ((this.acknowledgement != null) && (this.acknowledgement == Acknowledgement.TRUE)) {
			result.append(this.acknowledgement);
		}
		result.append(';');

		if (this.mac != null) {
			result.append(this.mac);
		}

		result.append(';');

		return result;
	}

	/**
	 * Remove useless semicolons
	 *
	 * @param message Original message
	 * @return Shortend message
	 */
	public static String removeSemicolons(String message) {
		while (message.endsWith(";")) {
			message = message.substring(0, message.length() - 1);
		}
		return message;
	}

}
